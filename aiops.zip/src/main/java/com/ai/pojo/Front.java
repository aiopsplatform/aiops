package com.ai.pojo;

public class Front {

    private String indexes;

    public Front(String indexes) {
        this.indexes = indexes;
    }

    public String getIndexes() {
        return indexes;
    }

    public void setIndexes(String indexes) {
        this.indexes = indexes;
    }

    public Front(){
        super();
    }

}
